const PLANOS = [
  { id: 'bronze', nome: 'Plano Bronze' },
  { id: 'prata', nome: 'Plano Prata' },
  { id: 'ouro', nome: 'Plano Ouro' }
];
let editId = null;

function carregarPlanos() {
  const sel = document.getElementById('aluno_plano');
  sel.innerHTML = '<option value="">Selecione um plano</option>';
  PLANOS.forEach(p => {
    sel.innerHTML += `<option value="${p.id}">${p.nome}</option>`;
  });
}

function carregarAlunos() {
  const alunos = JSON.parse(localStorage.getItem('alunos') || '[]');
  const tbody = document.querySelector('#tb_alunos tbody');
  tbody.innerHTML = '';
  alunos.forEach((a, idx) => {
    const plano = PLANOS.find(p => p.id === a.planoId);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${idx + 1}</td>
      <td>${a.nome}</td>
      <td>${a.idade || ''}</td>
      <td>${a.email || ''}</td>
      <td>${plano ? plano.nome : ''}</td>
      <td>
        <button onclick="editarAluno(${idx})">Editar</button>
        <button onclick="excluirAluno(${idx})">Excluir</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function setMsg(txt, ok = true) {
  const el = document.getElementById('aluno_msg');
  el.textContent = txt;
  el.className = ok ? 'ok' : 'err';
  setTimeout(() => { el.textContent = ''; }, 2000);
}

function salvarAluno() {
  const nome = document.getElementById('aluno_nome').value.trim();
  const idade = Number(document.getElementById('aluno_idade').value) || null;
  const email = document.getElementById('aluno_email').value.trim() || null;
  const tel = document.getElementById('aluno_tel').value.trim() || null;
  const peso = Number(document.getElementById('aluno_peso').value) || null;
  const altura = Number(document.getElementById('aluno_altura').value) || null;
  const planoId = document.getElementById('aluno_plano').value || null;
  if (!nome) { setMsg('Preencha o nome', false); return; }

  const alunos = JSON.parse(localStorage.getItem('alunos') || '[]');
  const aluno = { nome, idade, email, tel, peso, altura, planoId };
  if (editId !== null) {
    alunos[editId] = aluno;
    setMsg('Alterado com sucesso!');
  } else {
    alunos.push(aluno);
    setMsg('Salvo com sucesso!');
  }
  localStorage.setItem('alunos', JSON.stringify(alunos));
  resetForm();
  carregarAlunos();
}

function editarAluno(idx) {
  const alunos = JSON.parse(localStorage.getItem('alunos') || '[]');
  const a = alunos[idx];
  editId = idx;
  document.getElementById('formTitle').textContent = 'Editar Aluno';
  document.getElementById('btnSalvar').textContent = 'Alterar';
  document.getElementById('btnCancelar').style.display = '';
  document.getElementById('aluno_nome').value = a.nome || '';
  document.getElementById('aluno_idade').value = a.idade || '';
  document.getElementById('aluno_email').value = a.email || '';
  document.getElementById('aluno_tel').value = a.tel || '';
  document.getElementById('aluno_peso').value = a.peso || '';
  document.getElementById('aluno_altura').value = a.altura || '';
  document.getElementById('aluno_plano').value = a.planoId || '';
}

function resetForm() {
  editId = null;
  document.getElementById('formTitle').textContent = 'Novo Aluno';
  document.getElementById('btnSalvar').textContent = 'Salvar';
  document.getElementById('btnCancelar').style.display = 'none';
  ['aluno_nome', 'aluno_idade', 'aluno_email', 'aluno_tel', 'aluno_peso', 'aluno_altura'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('aluno_plano').value = '';
}

function excluirAluno(idx) {
  if (!confirm('Confirma exclusão?')) return;
  const alunos = JSON.parse(localStorage.getItem('alunos') || '[]');
  alunos.splice(idx, 1);
  localStorage.setItem('alunos', JSON.stringify(alunos));
  carregarAlunos();
}

window.addEventListener('DOMContentLoaded', () => {
  carregarPlanos();
  carregarAlunos();
});
