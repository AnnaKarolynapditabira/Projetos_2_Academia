# Academia - Painel Admin (MySQL)

## Conteúdo do ZIP
- backend/
  - server.js (Node.js + MySQL)
  - package.json
- frontend/
  - admin.html
  - admin.css
  - app.js
- db.sql (script para criar banco e tabelas)

## Requisitos
- Node.js (v14+)
- MySQL rodando localmente (ou servidor acessível)

## Passo a passo (MySQL)
1. Importe o arquivo `db.sql` no seu MySQL:

```sql
-- no terminal mysql:
SOURCE /caminho/para/db.sql;
```

2. Configure variáveis de ambiente (opcional):
- DB_HOST (padrão: localhost)
- DB_USER (padrão: root)
- DB_PASS (padrão: vazio)
- DB_NAME (padrão: academia)

3. Instale dependências e rode o backend:
```bash
cd backend
npm install
npm start
```

O servidor rodará em http://localhost:3001 e a API estará em http://localhost:3001/api

4. Abra o frontend:
- Você pode abrir `frontend/admin.html` no navegador (recomendado usar um servidor estático para evitar bloqueio CORS):
```bash
# na pasta frontend
npx http-server -c-1 .
# então abra http://localhost:8080/admin.html
```

## Observações
- O painel permite cadastrar, editar e excluir alunos.
- Planos já são seedados pelo script `db.sql` ou pelo servidor se o banco estiver vazio.
- Se tiver problemas de conexão, verifique as credenciais do MySQL e se o serviço está rodando.

Se quiser, eu posso modificar o backend para SQLite (não precisa configurar MySQL) — diga se prefere essa opção.
