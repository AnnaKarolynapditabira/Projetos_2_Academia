// server.js - MySQL backend with CRUD for Alunos and Planos
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// MySQL connection config - altere se necessário
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'academia'
};

let pool;
async function initDb() {
  pool = await mysql.createPool({ ...dbConfig, waitForConnections: true, connectionLimit: 10 });
  // ensure tables exist
  await pool.query(`
    CREATE TABLE IF NOT EXISTS Planos (
      id_plano VARCHAR(50) PRIMARY KEY,
      nome_plano VARCHAR(150) NOT NULL,
      valor DECIMAL(10,2) DEFAULT 0,
      descricao TEXT
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS Alunos (
      id_aluno INT AUTO_INCREMENT PRIMARY KEY,
      nome VARCHAR(150) NOT NULL,
      idade INT,
      email VARCHAR(150),
      telefone VARCHAR(30),
      peso DECIMAL(6,2),
      altura DECIMAL(4,2),
      id_plano VARCHAR(50),
      FOREIGN KEY (id_plano) REFERENCES Planos(id_plano) ON DELETE SET NULL ON UPDATE CASCADE
    );
  `);
  // seed planos if not exists
  const [rows] = await pool.query("SELECT COUNT(*) as cnt FROM Planos");
  if (rows[0].cnt === 0) {
    const planos = [
      ['bronze','Plano Bronze',99.90,'Plano básico'],
      ['prata','Plano Prata',149.90,'Plano intermediário'],
      ['ouro','Plano Ouro',249.90,'Plano premium']
    ];
    for (const p of planos) {
      await pool.query("INSERT INTO Planos (id_plano,nome_plano,valor,descricao) VALUES (?, ?, ?, ?)", p);
    }
  }
}

app.get('/api/health', async (req, res) => {
  try {
    const [tables] = await pool.query("SHOW TABLES");
    res.json({ ok: true, tables: tables.map(t=>Object.values(t)[0]) });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/planos', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id_plano AS id, nome_plano AS nome, valor, descricao FROM Planos');
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao buscar planos' });
  }
});

app.get('/api/alunos', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        a.id_aluno AS id,
        a.nome,
        a.idade,
        a.email,
        a.telefone AS tel,
        a.peso,
        a.altura,
        a.id_plano AS planoId,
        p.nome_plano AS planoNome
      FROM Alunos a
      LEFT JOIN Planos p ON a.id_plano = p.id_plano
      ORDER BY a.id_aluno DESC
    `);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao buscar alunos' });
  }
});

app.post('/api/alunos', async (req, res) => {
  try {
    const { nome, idade, email, tel, peso, altura, planoId } = req.body || {};
    if (!nome) return res.status(400).json({ error: 'nome é obrigatório' });
    const [result] = await pool.query(`INSERT INTO Alunos (nome, idade, email, telefone, peso, altura, id_plano) VALUES (?,?,?,?,?,?,?)`,
      [nome, idade || null, email || null, tel || null, peso || null, altura || null, planoId || null]);
    const id = result.insertId;
    const [row] = await pool.query("SELECT id_aluno AS id, nome FROM Alunos WHERE id_aluno = ?", [id]);
    res.status(201).json(row[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/alunos/:id', async (req, res) => {
  try {
    const { nome, idade, email, tel, peso, altura, planoId } = req.body;
    await pool.query(
      `UPDATE Alunos SET nome=?, idade=?, email=?, telefone=?, peso=?, altura=?, id_plano=?
       WHERE id_aluno=?`,
      [nome, idade, email, tel, peso, altura, planoId, req.params.id]
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao atualizar aluno' });
  }
});

app.delete('/api/alunos/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM Alunos WHERE id_aluno=?', [req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao excluir aluno' });
  }
});

initDb().then(()=>{
  app.listen(PORT, ()=> console.log(`Servidor MySQL rodando em http://localhost:${PORT}`));
}).catch(err=>{
  console.error("Erro inicializando banco:", err);
  process.exit(1);
});
