-- db.sql - criar banco e tabelas para Academia (MySQL)
CREATE DATABASE IF NOT EXISTS academia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE academia;

DROP TABLE IF EXISTS Alunos;
DROP TABLE IF EXISTS Planos;

CREATE TABLE IF NOT EXISTS Planos (
  id_plano VARCHAR(50) PRIMARY KEY,
  nome_plano VARCHAR(150) NOT NULL,
  valor DECIMAL(10,2) DEFAULT 0,
  descricao TEXT
);

CREATE TABLE IF NOT EXISTS Alunos (
  id_aluno INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  idade INT,
  email VARCHAR(150),
  telefone VARCHAR(30),
  peso DECIMAL(6,2),
  altura DECIMAL(4,2),
  id_plano VARCHAR(50),
  FOREIGN KEY (id_plano) REFERENCES Planos(id_plano) ON DELETE SET NULL ON UPDATE CASCADE
);

INSERT IGNORE INTO Planos (id_plano, nome_plano, valor, descricao) VALUES
('bronze','Plano Bronze',99.90,'Plano básico'),
('prata','Plano Prata',149.90,'Plano intermediário'),
('ouro','Plano Ouro',249.90,'Plano premium');
